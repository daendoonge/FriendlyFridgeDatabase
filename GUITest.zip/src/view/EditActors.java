package view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JPanel;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.factories.FormFactory;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Statement;

public class EditActors extends JInternalFrame {

	/**
	 * Create the frame.
	 */
	private static JTextField oldName;
	private static JTextField oldGender;
	private static JTextField newName;
	private static JTextField newGender;
	private static JTextField newBD;
	
	public static void Update (Statement state) {
		 try {
			 if (!newBD.getText().isEmpty())
				 state.executeUpdate("Update Actors set [B-Day] = '" + newBD.getText() + "' where Name = '" + oldName.getText() + "' and Gender = '" + oldGender.getText() + "';" );
			 if (!newName.getText().isEmpty())
				 state.executeUpdate("Update Actors set Name = '" + newName.getText() + "' where Name = '" + oldName.getText() + "' and Gender = '" + oldGender.getText() + "';" );
			 
			 if (!newGender.getText().isEmpty())
				 state.executeUpdate("Update Actors set Gender = '" + newGender.getText() + "' where Name = '" + oldName.getText() + "' and Gender = '" + oldGender.getText() + "';" );
		 }
		 catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
	 }
	public EditActors() {
		setClosable(true);
		setMaximizable(true);
		setFrameIcon(new ImageIcon(EditMusic.class.getResource("/images/actor.jpg")));
		setIconifiable(true);
		setTitle("Editing Actors");
		setBounds(0, 0, 375, 350);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Editing Data", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "New Data (Leave Blank if unchanged)", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_2 = new JPanel();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 367, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 367, Short.MAX_VALUE)
					.addContainerGap())
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 377, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 87, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 126, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		
		JButton btnAccept = new JButton("Accept");
		btnAccept.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Update(MovieMenu.statement);
				dispose();
			}
		});
		btnAccept.setIcon(new ImageIcon(EditMusic.class.getResource("/images/accept.png")));
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancel.setIcon(new ImageIcon(EditMusic.class.getResource("/images/cancel.png")));
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(70)
					.addComponent(btnAccept)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnCancel)
					.addContainerGap(67, Short.MAX_VALUE))
		);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAccept)
						.addComponent(btnCancel, GroupLayout.PREFERRED_SIZE, 52, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(2, Short.MAX_VALUE))
		);
		panel_2.setLayout(gl_panel_2);
		panel_1.setLayout(new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("default:grow"),},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,}));
		
		JLabel lblTitle_1 = new JLabel("Name");
		panel_1.add(lblTitle_1, "2, 2, right, default");
		
		newName = new JTextField();
		panel_1.add(newName, "4, 2, fill, default");
		newName.setColumns(10);
		
		JLabel lblYear_1 = new JLabel("Gender");
		panel_1.add(lblYear_1, "2, 4, right, default");
		
		newGender = new JTextField();
		panel_1.add(newGender, "4, 4, fill, default");
		newGender.setColumns(10);
		
		JLabel lblDirector = new JLabel("B-Date");
		panel_1.add(lblDirector, "2, 6, right, default");
		
		newBD = new JTextField();
		panel_1.add(newBD, "4, 6, fill, default");
		newBD.setColumns(10);
		panel.setLayout(new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("default:grow"),},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,}));
		
		JLabel lblTitle = new JLabel("Name");
		panel.add(lblTitle, "2, 2, right, default");
		
		oldName = new JTextField();
		panel.add(oldName, "4, 2, fill, default");
		oldName.setColumns(10);
		
		JLabel lblYear = new JLabel("Gender");
		panel.add(lblYear, "2, 4, right, default");
		
		oldGender = new JTextField();
		panel.add(oldGender, "4, 4, fill, default");
		oldGender.setColumns(10);
		getContentPane().setLayout(groupLayout);

	}
}
