package view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextArea;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Statement;
import java.sql.ResultSet;

public class reportDatabase extends JInternalFrame {
	private static JTextArea textArea;
	private JRadioButton rdbtnMovies;
	private JRadioButton rdbtnActors;
	private JRadioButton rdbtnStudio;
	private JRadioButton rdbtnMusic;
	private static String Table;

	/**
	 * Create the frame.
	 */
	
	public static void runReport(Statement state) {
		try {
			ResultSet rs = state.executeQuery("SELECT * FROM " + Table + ";");
			System.out.print("");
		}
		catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
	}
	public reportDatabase() {
		setTitle("Report from Database");
		setClosable(true);
		setMaximizable(true);
		setIconifiable(true);
		setBounds(0, 0, 500, 500);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Select Table", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_1 = new JPanel();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(10)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 466, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE))
		);
		
		textArea = new JTextArea();
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addComponent(textArea, GroupLayout.PREFERRED_SIZE, 465, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addComponent(textArea, GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
					.addContainerGap())
		);
		panel_1.setLayout(gl_panel_1);
		
		rdbtnMovies = new JRadioButton("Movies");
		rdbtnMovies.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Table = "Movies";
				runReport(MovieMenu.statement);
				
			}
		});
		rdbtnMovies.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				Table = "";
				textArea.removeAll();
			}
		});
		panel.add(rdbtnMovies);
		
		rdbtnActors = new JRadioButton("Actors");
		rdbtnActors.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Table = "Actors";
				runReport(MovieMenu.statement);
				
			}
		});
		rdbtnActors.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				Table = "";
				textArea.removeAll();
			}
		});
		panel.add(rdbtnActors);
		
		rdbtnStudio = new JRadioButton("Studio");
		rdbtnStudio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Table = "Studio";
				runReport(MovieMenu.statement);
				
			}
		});
		rdbtnStudio.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				Table = "";
				textArea.removeAll();
			}
		});
		panel.add(rdbtnStudio);
		
		rdbtnMusic = new JRadioButton("Music");
		rdbtnMusic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Table = "Music";
				runReport(MovieMenu.statement);
				
			}
		});
		rdbtnMusic.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				Table = "";
				textArea.removeAll();
			}
		});
		panel.add(rdbtnMusic);
		getContentPane().setLayout(groupLayout);
	}

}
