package view;

import java.awt.EventQueue;
import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import java.awt.GridLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.RowSpec;
import net.miginfocom.swing.MigLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.sql.Statement;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class RemoveDatabase extends JInternalFrame {
	private static JTextField name;
	private JRadioButton rdbtnMovies;
	private JRadioButton rdbtnActors;
	private JRadioButton rdbtnStudios;
	private JRadioButton rdbtnMusic;
	private static String tableName;
	
	public static void Remove (Statement state) {
		try {
		state.executeUpdate("DELETE FROM " + tableName + " WHERE Name = '" + name.getText() + "';");
		}
		catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
	}
	public RemoveDatabase() {
		setTitle("Removing from Database");
		setClosable(true);
		setMaximizable(true);
		setIconifiable(true);
		setBounds(0, 0, 500, 300);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Choose Table", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel RDPane = new JPanel();
		RDPane.setBorder(new TitledBorder(null, "Information", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_1 = new JPanel();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(RDPane, GroupLayout.DEFAULT_SIZE, 474, Short.MAX_VALUE)
					.addContainerGap())
				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 473, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(RDPane, GroupLayout.PREFERRED_SIZE, 107, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE))
		);
		
		JButton btnAccept = new JButton("Accept");
		btnAccept.setIcon(new ImageIcon(RemoveDatabase.class.getResource("/images/accept.png")));
		btnAccept.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Remove(MovieMenu.statement);
				dispose();
			}
		});
		panel_1.add(btnAccept);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancel.setIcon(new ImageIcon(RemoveDatabase.class.getResource("/images/cancel.png")));
		panel_1.add(btnCancel);
		
		JLabel lblName = new JLabel("Name or Title");
		
		name = new JTextField();
		name.setColumns(10);
		GroupLayout gl_RDPane = new GroupLayout(RDPane);
		gl_RDPane.setHorizontalGroup(
			gl_RDPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_RDPane.createSequentialGroup()
					.addComponent(lblName)
					.addGap(39)
					.addComponent(name, GroupLayout.PREFERRED_SIZE, 320, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(63, Short.MAX_VALUE))
		);
		gl_RDPane.setVerticalGroup(
			gl_RDPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_RDPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_RDPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblName)
						.addComponent(name, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(369, Short.MAX_VALUE))
		);
		RDPane.setLayout(gl_RDPane);
		
		rdbtnMovies = new JRadioButton("Movies");
		rdbtnMovies.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			tableName = "Movies";	
			}
		});
		panel.add(rdbtnMovies);
		
		rdbtnActors = new JRadioButton("Actors");
		rdbtnActors.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tableName = "Actors";
			}
		});
		panel.add(rdbtnActors);
		
		rdbtnStudios = new JRadioButton("Studios");
		rdbtnStudios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tableName = "Studio";
			}
		});
		panel.add(rdbtnStudios);
		
		rdbtnMusic = new JRadioButton("Music");
		rdbtnMusic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tableName = "Music";
			}
		});
		panel.add(rdbtnMusic);
		getContentPane().setLayout(groupLayout);

	}
}
