package view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ImageIcon;

public class EditDatabase extends JInternalFrame {

	private JPanel editPane;
	private JButton movieBtn;
	private JButton actorsBtn;
	private JButton studioBtn;
	private JButton musicBtn;
	private EditMovie EMo;
	private EditActors EA;
	private EditStudio ES;
	private EditMusic EMu;
	
	private void CreateEvents() {
		movieBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (EMo == null || EMo.isClosed())
				{
					EMo = new EditMovie();
					editPane.add(EMo);
					EMo.show();
				}
			}
		});
		actorsBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (EA == null || EA.isClosed())
				{
					EA = new EditActors();
					editPane.add(EA);
					EA.show();
				}
			}
		});
		studioBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (ES == null || ES.isClosed())
				{
					ES = new EditStudio();
					editPane.add(ES);
					ES.show();
				}
			}
		});
		
		musicBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (EMu == null || EMu.isClosed())
				{
					EMu = new EditMusic();
					editPane.add(EMu);
					EMu.show();
				}
			}
		});
		
		
	}
	
	private void initializeComponents() {

		setTitle("Editing Database");
		setClosable(true);
		setMaximizable(true);
		setIconifiable(true);
		setBounds(0,0, 500, 500);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Select the table to edit", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		editPane = new JPanel();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(editPane, GroupLayout.PREFERRED_SIZE, 460, GroupLayout.PREFERRED_SIZE)
						.addComponent(panel, GroupLayout.DEFAULT_SIZE, 464, Short.MAX_VALUE))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(editPane, GroupLayout.DEFAULT_SIZE, 391, Short.MAX_VALUE))
		);
		
		movieBtn = new JButton("Movie");
		panel.add(movieBtn);
		
		actorsBtn = new JButton("Actors");
		panel.add(actorsBtn);
		
		studioBtn = new JButton("Studio");
		panel.add(studioBtn);
		
		musicBtn = new JButton("Music");
		panel.add(musicBtn);
		getContentPane().setLayout(groupLayout);
		
	}
	
	
	public EditDatabase() {
		initializeComponents();
		CreateEvents();
	}
}
