package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.ResultSet;  
import java.sql.Statement;  
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.SwingConstants;

public class MovieMenu extends JFrame {
	public static Statement statement;
	public static Connection conn;
	private JPanel contentPane;
	private JPanel desktopPane;
	private JButton addMovie;
	private JButton addStudio;
	private JButton addMusic;
	private JButton addActor;
	private JButton editDatabase;
	private JButton searchDatabase;
	private JButton removeFromDatabase;
	private InsertMovies IMo;
	private InsertActors IA;
	private InsertStudio IS;
	private InsertMusic IMu;
	private EditDatabase ED;
	private RemoveDatabase RD;
	private reportDatabase rD;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MovieMenu frame = new MovieMenu();
					frame.setVisible(true);
					conn = CreateConnection();
				   	statement = conn.createStatement();
				   	Create(conn);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static Connection CreateConnection() {
		  Connection conn = null;
		  try 
		     { 
	      Class.forName("org.sqlite.JDBC");  
	      conn = DriverManager.getConnection("jdbc:sqlite:Movies.db");
	      
		     }
		  catch (Exception e) 
		     {  
		         e.printStackTrace();  
		     }
		  return conn;
	  }
	public static void Create (Connection conn) {
		try {
			  Statement statement = conn.createStatement();
			  statement.executeUpdate("CREATE TABLE Movies (ID INTEGER  PRIMARY KEY ASC, Name     CHAR( 50 ), Director CHAR( 50 ), Length   VARCHAR, Year     INT, Genre    CHAR( 20 ));"); 
			  statement.executeUpdate("CREATE TABLE Actors ( Name    CHAR( 50 ),[B-Day] DATE,Gender  CHAR( 6 ) );");
			  statement.executeUpdate("CREATE TABLE Contracts ( actorName  CHAR( 50 ), studioName CHAR( 50 ), movieID    INTEGER, Salary     REAL );");
			  statement.executeUpdate("CREATE TABLE Music (Name     CHAR( 50 ),Year     INT, Composer CHAR( 50 ))");
			  statement.executeUpdate("CREATE TABLE ProducedBy ( movieID    INTEGER, studioName CHAR( 50 ));");
			  statement.executeUpdate("CREATE TABLE Starsin ( movieID   INTEGER, actorName CHAR( 50 ));");
			  statement.executeUpdate("CREATE TABLE Studio (Name CHAR( 50 ), Address VARCHAR( 50 ));");
			  statement.executeUpdate("CREATE TABLE Used ( musicName  CHAR( 50 ), musicComposer CHAR( 50 ), movieID  INTEGER );");

		}
			  catch (Exception e) 
			     {  
			         e.printStackTrace();  
			     }
	}
	 public static void close (Connection conn, Statement statement) {
		  try {
			  conn.close();
		      statement.close();
		  }
		  catch(SQLException e){
		      // if the error message is "out of memory", 
		      // it probably means no database file is found
		      System.err.println(e.getMessage());
		  }
	 }	 
	/**
	 * Create the frame.
	 */
	public MovieMenu() {
		initCompoments();
		CreateEvents();
	}
	private void CreateEvents() {
		addMovie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (IMo == null || IMo.isClosed()) {
					IMo = new InsertMovies();
					desktopPane.add(IMo);
					IMo.show();
				}
			}
		});
		addStudio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (IS == null || IS.isClosed()) {
					IS = new InsertStudio();
					desktopPane.add(IS);
					IS.show();
				}
			}
		});
		addMusic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (IMu == null || IMu.isClosed()) {
					IMu = new InsertMusic();
					desktopPane.add(IMu);
					IMu.show();
				}
			}
		});
		addActor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (IA == null || IA.isClosed()) {
					IA = new InsertActors();
					desktopPane.add(IA);
					IA.show();
				}
			}
		});
		editDatabase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (ED == null || ED.isClosed()) {
					ED = new EditDatabase();
					desktopPane.add(ED);
					ED.show();
				}
			}
		});
		removeFromDatabase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (RD == null || RD.isClosed()) {
					RD = new RemoveDatabase();
					desktopPane.add(RD);
					RD.show();
				}
			}
		});
		searchDatabase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (rD == null || rD.isClosed()) {
					rD = new reportDatabase();
					desktopPane.add(rD);
					rD.show();
				}
			}
		});
		
	}
	
	private void initCompoments() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(MovieMenu.class.getResource("/images/titleicon.png")));
		setTitle("Friendly Movie Database ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 600);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mntmNewMenuItem.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/smallcancel.png")));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenu mnNewMenu_1 = new JMenu("Edit");
		menuBar.add(mnNewMenu_1);
		
		JMenu mnAbout = new JMenu("About");
		menuBar.add(mnAbout);
		
		JMenuItem mntmAboutUs = new JMenuItem("About Us");
		mntmAboutUs.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/info.png")));
		mnAbout.add(mntmAboutUs);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(false);
		
		JToolBar toolBar_1 = new JToolBar();
		toolBar_1.setFloatable(false);
		
		JToolBar toolBar_2 = new JToolBar();
		toolBar_2.setFloatable(false);
		
		JToolBar toolBar_3 = new JToolBar();
		toolBar_3.setFloatable(false);
		
		desktopPane = new JPanel();
		
		JToolBar toolBar_4 = new JToolBar();
		toolBar_4.setFloatable(false);
		
		JToolBar toolBar_5 = new JToolBar();
		toolBar_5.setFloatable(false);
		
		JToolBar toolBar_6 = new JToolBar();
		toolBar_6.setFloatable(false);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(toolBar_4, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
								.addComponent(toolBar, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
								.addComponent(toolBar_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
								.addComponent(toolBar_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
								.addComponent(toolBar_1, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
								.addComponent(toolBar_6, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE))
							.addGap(18))
						.addComponent(toolBar_5, GroupLayout.PREFERRED_SIZE, 166, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(desktopPane, GroupLayout.PREFERRED_SIZE, 524, GroupLayout.PREFERRED_SIZE)
					.addGap(5))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(19)
					.addComponent(toolBar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(toolBar_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(toolBar_3, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(toolBar_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(toolBar_4, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(toolBar_5, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(toolBar_6, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE)
					.addGap(25))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(desktopPane, GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE))
		);
		
		removeFromDatabase = new JButton("Remove From Database");
		removeFromDatabase.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/cancel.png")));
		toolBar_6.add(removeFromDatabase);
		
		editDatabase = new JButton("Edit Database");
		editDatabase.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/edit.png")));
		toolBar_5.add(editDatabase);
		
		searchDatabase = new JButton("Database Report");
		searchDatabase.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/search.jpg")));
		toolBar_4.add(searchDatabase);
		GroupLayout gl_desktopPane = new GroupLayout(desktopPane);
		gl_desktopPane.setHorizontalGroup(
			gl_desktopPane.createParallelGroup(Alignment.LEADING)
				.addGap(0, 482, Short.MAX_VALUE)
		);
		gl_desktopPane.setVerticalGroup(
			gl_desktopPane.createParallelGroup(Alignment.LEADING)
				.addGap(0, 412, Short.MAX_VALUE)
		);
		desktopPane.setLayout(gl_desktopPane);
		addMovie = new JButton("Add Item to Movie ");
		toolBar.add(addMovie);
		addMovie.setHorizontalAlignment(SwingConstants.LEFT);
		
		addMovie.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/menu.png")));
		
		addMusic = new JButton("Add Item to Music");
		toolBar_3.add(addMusic);
		addMusic.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/music.jpg")));
		
		addStudio = new JButton("Add Item to Studio");
		
		toolBar_2.add(addStudio);
		addStudio.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/studio.png")));
		
		addActor = new JButton("Add Item to Actor");
		addActor.setHorizontalAlignment(SwingConstants.LEFT);
		addActor.setIcon(new ImageIcon(MovieMenu.class.getResource("/images/actor.jpg")));
		toolBar_1.add(addActor);
		contentPane.setLayout(gl_contentPane);
		
		
	}
}
